SQL VS NOSQL
============

Exercise 1 - Agriculture Tech
-----------------------------

## SQL vs NoSQL System Design

### Scenario 1: Crop Yield Prediction System

1. Problem Description:
The client, a leading agriculture tech company, wants to develop a crop yield prediction system. The current challenge faced by farmers is the unpredictable crop yield due to various factors such as weather conditions, soil quality, disease outbreaks, and pest attacks. They aim to overcome these limitations by leveraging data-driven insights and predictive modeling techniques. Additionally, the client wants to include AI/ML capabilities in order to improve the accuracy of yield prediction. The client faces tough competition in the market from other agriculture tech companies and wants to create a system that can handle a large number of concurrent users.

2. Expectations and Acceptance Criteria:
- The system should be able to handle concurrent user load of at least 10,000 users.
- The system should provide real-time insights and predictions with a latency of less than 1 second.
- The accuracy of the crop yield predictions should be at least 90%.
- The system should be designed to handle large volumes of historical weather, soil, and crop data.
- The system should be able to scale horizontally to cater to future growth in user base and data volume.
- The AI/ML models used for crop yield prediction should be trained and updated periodically to incorporate new data and improve accuracy.
- The system should provide individualized recommendations to farmers based on the predicted yield and other factors.

3. SQL vs NoSQL Considerations:
- When choosing the database for storing historical weather, soil, and crop data, SQL databases like MySQL or PostgreSQL can be used. SQL databases excel in handling structured data and complex queries. In this case, the historical data is likely to have a well-defined schema and require complex queries for analysis.
- For the real-time prediction system, NoSQL databases like MongoDB or Cassandra can be considered. NoSQL databases provide high performance and scalability, which is critical for handling large concurrent user loads and providing real-time insights with low latency.
- The AI/ML models can be trained and stored in a NoSQL database for faster retrieval and updates.

### Scenario 2: Precision Farming System

1. Problem Description:
The client, a precision farming solutions provider, aims to develop a comprehensive system that optimizes farm operations based on real-time data. The current challenges faced by farmers include improper resource allocation, suboptimal irrigation, inefficient pest control, and lack of automation. The client wants to integrate various sensors, machinery, and AI/ML algorithms to provide actionable insights and automate farming practices. The system should also consider the environmental impact and sustainability of farming practices. The client faces competition from other precision farming solutions providers and wants to create a high-performance system capable of handling a large amount of data.

2. Expectations and Acceptance Criteria:
- The system should be able to handle a large number of sensors and IoT devices sending real-time data from the farm.
- The system should provide real-time insights and recommendations for resource allocation, irrigation scheduling, and pest control.
- The system should optimize resource usage to minimize wastage and reduce environmental impact.
- The system should be scalable to handle data from farms of different sizes and operate efficiently even during peak farming seasons.
- The AI/ML algorithms used for decision-making should be trained on a combination of real-time and historical data.
- The system should support automation of various farming operations such as irrigation, pesticide spraying, and fertilization.
- The system should generate comprehensive reports and analytics for farmers to track performance and make informed decisions.

3. SQL vs NoSQL Considerations:
- For storing the historical data and complex farm analytics, SQL databases can be used. SQL databases excel at handling structured data, complex joins, and aggregations required for farm analytics.
- NoSQL databases can be used to store sensor data and other real-time information. NoSQL databases provide high write throughput, scalability, and flexible schema design, which are essential for handling real-time data from sensors and IoT devices.
- The AI/ML models can be trained and stored in a NoSQL database for faster retrieval and updates.

### Scenario 3: Supply Chain Management System

1. Problem Description:
The client, an agricultural supplier, wants to develop a supply chain management system that can efficiently handle their diverse product portfolio and distribution network. The current challenge faced by the client includes managing large inventories, handling perishable products, optimizing transportation routes, and ensuring timely delivery to customers. The client wants to leverage technology and data-driven insights to improve operational efficiency, reduce wastage, and enhance customer satisfaction. The system should be able to handle a significant number of concurrent users, considering the client's existing customer base and potential growth.

2. Expectations and Acceptance Criteria:
- The system should be able to handle a large number of products, suppliers, and customers.
- The system should automate inventory management, including tracking stock levels, expiration dates, and optimizing replenishment.
- The system should optimize transportation routes and schedules to minimize costs and ensure timely delivery.
- The system should provide real-time visibility of the supply chain to all stakeholders, including suppliers, customers, and internal teams.
- The system should handle complex pricing and discount structures based on different customer segments and product types.
- The system should generate real-time reports and analytics for monitoring key performance indicators and making data-driven decisions.
- The system should be scalable to handle future growth in both customer base and product portfolio.

3. SQL vs NoSQL Considerations:
- SQL databases can be used for storing and managing the structured data related to products, suppliers, customers, inventory, and pricing. SQL databases provide robust data consistency and support complex queries for inventory management and price calculations.
- For real-time tracking of transportation routes and schedules, NoSQL databases can be used. NoSQL databases provide high write throughput and flexible schema design, which are crucial for handling real-time data and updates from multiple sources.
- The AI/ML models for demand forecasting and route optimization can be trained and stored in a NoSQL database to leverage its scalability and performance.

---

Core Topics:

1. Data Modeling
2. Schema Design
3. Joins & Aggregations
4. Indexing & Query Optimization
5. Scalability & Performance
6. ACID vs BASE
7. CAP Theorem

Use cases and system design considerations for each of the core topics will be provided below.
