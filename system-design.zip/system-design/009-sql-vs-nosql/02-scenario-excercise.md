SQL VS NOSQL
============

Exercise 1 - Ecommrce
---------------------

## SQL vs NoSQL System Design Use Case Scenarios

### 1. Problem Description:
Our client is a leading e-commerce platform, facing challenges with their current SQL-based system. They are experiencing limitations in terms of scalability, performance, and flexibility. The client envisions a system that can handle a high concurrent user load, have the ability to leverage AI/ML techniques for personalized recommendations, and be easily adaptable to evolving business requirements. They are also facing tough competition in the market, and therefore, need to differentiate themselves by providing a seamless customer experience.

### Expected Outcome:
The client expects the new system to provide the following features and meet the respective acceptance criteria:

1. Scalability: The system should be able to handle a minimum of 100,000 simultaneous users without significant performance degradation.
2. Performance: The system should be able to serve page requests in under 500ms 95% of the time.
3. Flexibility: The system should be able to easily adapt to changes in the business requirements without undergoing major architectural changes.
4. AI/ML Usage: The system should be able to leverage AI/ML techniques to provide personalized product recommendations for each user.
5. Competition: The system should provide a seamless shopping experience, ensuring smooth browsing, searching, and purchasing flows for the users.

### Instructions:
For this use case, the focus will be on the SQL vs NoSQL system design comparison. Each team member should come up with a minimum of 3 solution approaches for the given problem. The following parameters should be considered in the system design for each approach:

1. Data Model: Describe the schema or structure of the underlying data and how different entities are related.
2. Query Patterns: Identify the most common types of queries or operations that would be performed on the data.
3. Data Volume: Estimate the expected data volume based on the number of concurrent users and the frequency of data updates.
4. Performance Optimization: Propose techniques or strategies to optimize the system's performance, such as indexing, caching, or query optimization.
5. Scalability: Discuss how the system would handle increasing load and concurrent user traffic.
6. Data Consistency: Address the consistency requirements for the system, considering both ACID (Atomicity, Consistency, Isolation, Durability) and BASE (Basically Available, Soft state, Eventually consistent) principles.
7. Fault Tolerance: Analyze the potential failure points and propose mechanisms to ensure high availability and fault tolerance.
8. Integration: Consider any integrations required with other systems, such as payment gateways, inventory management, or external APIs.
9. Security: Highlight the security measures that need to be implemented, such as encryption, access control, or data privacy regulations compliance.

Please note that each solution approach should clearly highlight the pros and cons of using SQL or NoSQL systems in the given scenario. The comparison should cover aspects like data modeling, querying capabilities, performance, scalability, consistency, fault tolerance, integration, and security.

### Core Topics:
1. Data Modeling and Schema Design
2. Query Patterns and Optimization
3. Scalability and Performance
4. Data Consistency and Replication
5. Fault Tolerance and High Availability
6. Integration with External Systems
7. Security and Compliance

The use case scenarios described above should be used for group discussions, case studies, or hands-on exercises to evaluate the team's understanding of SQL and NoSQL system design in a real-world context.
