PERFORMANCE VS SCALABILITY
==========================

Exercise 1 - Telecommunications
-------------------------------

**Problem Description**

**Client:** A leading telecommunications company is experiencing a surge in customer demand for its mobile broadband services. The company's current network is struggling to keep up with the increased traffic, resulting in slow speeds, dropped calls, and poor customer satisfaction. The company is seeking a solution that will enable it to scale its network to meet the growing demand while maintaining high levels of performance.

**Challenges:**

* The company's current network is based on legacy technology that is not capable of handling the increased traffic.
* The company's network is geographically dispersed, with multiple data centers and cell towers. This makes it difficult to manage and scale the network.
* The company's customers are demanding high-speed, reliable, and affordable mobile broadband services.
* The company is facing stiff competition from other telecommunications companies that are also investing in their networks.

**Business Vision:**

The company's business vision is to be the leading provider of mobile broadband services in the region. The company wants to provide its customers with the best possible experience, regardless of where they are or what device they are using.

**Expected Concurrent User Load:**

The company expects to have 10 million concurrent users on its network by the end of the year. This number is expected to grow to 20 million users by the end of the next year.

**AI/ML Usage:**

The company plans to use AI/ML to improve the performance and scalability of its network. The company wants to use AI/ML to:

* Predict and prevent network congestion.
* Optimize the allocation of network resources.
* Identify and fix network problems.

**Acceptance Criteria:**

The company's new network must meet the following acceptance criteria:

* The network must be able to handle 10 million concurrent users by the end of the year and 20 million concurrent users by the end of the next year.
* The network must provide high-speed, reliable, and affordable mobile broadband services.
* The network must be able to scale to meet the growing demand for mobile broadband services.
* The network must be able to use AI/ML to improve performance and scalability.

**Topic:**

Performance vs Scalability System Design

**Instructions:**

Come up with a minimum of 3 solutions, approaches, and a list of parameters that should be included in the system design to meet the acceptance criteria.

**Solution 1:**

* **Solution:** Deploy a new network based on next-generation technology, such as 5G.
* **Approach:**
    * Use a distributed architecture to improve scalability.
    * Use software-defined networking (SDN) to manage and control the network.
    * Use AI/ML to optimize the performance and scalability of the network.
* **Parameters:**
    * Number of cells and cell towers
    * Capacity of each cell and cell tower
    * Backhaul capacity
    * Core network capacity
    * AI/ML algorithms

**Solution 2:**

* **Solution:** Upgrade the existing network to increase its capacity.
* **Approach:**
    * Replace legacy equipment with new, higher-capacity equipment.
    * Expand the network by adding new cells and cell towers.
    * Upgrade the backhaul and core network to increase capacity.
    * Use AI/ML to optimize the performance and scalability of the network.
* **Parameters:**
    * Number of cells and cell towers
    * Capacity of each cell and cell tower
    * Backhaul capacity
    * Core network capacity
    * AI/ML algorithms

**Solution 3:**

* **Solution:** Use a combination of solutions 1 and 2.
* **Approach:**
    * Deploy a new network based on next-generation technology in areas with high demand.
    * Upgrade the existing network in areas with lower demand.
    * Use AI/ML to optimize the performance and scalability of the network.
* **Parameters:**
    * Number of cells and cell towers
    * Capacity of each cell and cell tower
    * Backhaul capacity
    * Core network capacity
    * AI/ML algorithms
